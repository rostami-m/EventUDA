This folder contains our code implementation for CIFAR10-DVS.

To run our code, you can first download the datasets using the following links. Then change the file paths in config/seetings.yaml file and train the model through 'train.ipynb'.

Datasets:
CIFAR10 and CIFAR10-DVS:
CIFAR10 dataset can be downloaded here:
https://www.cs.toronto.edu/~kriz/cifar.html
CIFAR10-DVS dataset can be downloaded here:
https://figshare.com/articles/dataset/CIFAR10-DVS_New/4724671/2
