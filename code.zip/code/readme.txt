This folder contains our code implementation.
There are two sub-folders which are code implementations for (Caltech101,N-Caltech101) pair and (CIFAR10,CIFAR10-DVS) pair respectively. 
We did not merge them because 
1. hyperparameter settings are very different 
2. dataset input formats are very different
3. models are different due to different input image sizes
We think keeping them separate is more clear to follow.

To run our code, you can first download the datasets using the following links. Then go to the sub-folder, change the file paths and train the model through 'train.ipynb'.

Datasets:
Caltech101 and N-Caltech101:
This dataset pair can be downloaded here:
https://rpg.ifi.uzh.ch/data/VID2E/Paired_N-Caltech101.zip

CIFAR10 and CIFAR10-DVS:
CIFAR10 dataset can be downloaded here:
https://www.cs.toronto.edu/~kriz/cifar.html
CIFAR10-DVS dataset can be downloaded here:
https://figshare.com/articles/dataset/CIFAR10-DVS_New/4724671/2
