This folder contains our code implementation for N-Caltech101.

To run our code, you can first download the datasets using the following links. Then change the file paths under config\settings.yaml and datasets\caltech101_loader.py and train the model through 'train.ipynb'.

Datasets:
Caltech101 and N-Caltech101:
This dataset pair can be downloaded here:
https://rpg.ifi.uzh.ch/data/VID2E/Paired_N-Caltech101.zip

